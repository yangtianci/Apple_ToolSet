//
//  ViewController.h
//  QRCode
//
//  Created by 王聪 on 16/5/22.
//  Copyright © 2016年 王聪. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

