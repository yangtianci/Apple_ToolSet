//
//  main.m
//  DQStarViewDemo
//
//  Created by 邓琪 dengqi on 2017/1/16.
//  Copyright © 2017年 邓琪 dengqi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
