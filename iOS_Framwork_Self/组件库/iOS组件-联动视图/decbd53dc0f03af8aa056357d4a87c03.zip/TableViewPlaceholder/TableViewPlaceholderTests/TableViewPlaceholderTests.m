//
//  TableViewPlaceholderTests.m
//  TableViewPlaceholderTests
//
//  Created by TengShuQiang on 2017/12/4.
//  Copyright © 2017年 TTeng. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "ViewController.h"

@interface TableViewPlaceholderTests : XCTestCase

@end

@implementation TableViewPlaceholderTests

- (void)setUp {
    [super setUp];
    
}

- (void)tearDown {
    
    [super tearDown];
}

- (void)testReloadData {
    
}

@end
