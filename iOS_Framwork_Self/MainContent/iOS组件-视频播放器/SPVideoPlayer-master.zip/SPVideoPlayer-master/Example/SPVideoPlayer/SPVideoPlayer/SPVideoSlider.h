//
//  SPVideoSlider.h
//  SPVideoPlayer
//
//  Created by Libo on 17/8/30.  （https://github.com/SPStore/SPVideoPlayer
//  Copyright © 2017年 iDress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SPVideoSlider : UISlider

@property (nonatomic, strong) UIImage *thumbBackgroundImage;

@end
