//
//  UINavigationController+SPPlayerRotation.h
//  SPVideoPlayer
//
//  Created by leshengping on 17/8/29.
//  Copyright © 2017年 leshengping. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationController (SPPlayerRotation) <UIGestureRecognizerDelegate>

@end
