//
//  SPVideoResolution.m
//  SPVideoPlayer
//
//  Created by leshengping on 17/8/23.
//  Copyright © 2017年 leshengping. All rights reserved.
//

#import "SPVideoResolution.h"

@implementation SPVideoResolution

@end
