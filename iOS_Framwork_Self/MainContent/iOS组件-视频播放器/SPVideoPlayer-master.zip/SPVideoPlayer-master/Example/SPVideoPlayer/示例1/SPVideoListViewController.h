//
//  SPVideoListViewController.h
//  SPVideoPlayer
//
//  Created by leshengping on 17/8/23.
//  Copyright © 2017年 leshengping. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SPVideoListViewController : UIViewController

@end
