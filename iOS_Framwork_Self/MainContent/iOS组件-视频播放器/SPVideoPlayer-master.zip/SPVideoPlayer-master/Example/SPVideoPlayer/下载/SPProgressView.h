//
//  SPProgressView.h
//  SPVideoPlayer
//
//  Created by Libo on 17/9/4.
//  Copyright © 2017年 iDress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SPProgressView : UIView
@property (assign, nonatomic) CGFloat progress;

@end
