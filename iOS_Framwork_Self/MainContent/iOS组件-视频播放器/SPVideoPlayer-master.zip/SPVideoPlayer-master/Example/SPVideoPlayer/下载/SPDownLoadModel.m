//
//  SPDownLoadModel.m
//  SPVideoPlayer
//
//  Created by Libo on 17/9/2.
//  Copyright © 2017年 iDress. All rights reserved.
//

#import "SPDownLoadModel.h"

@implementation SPDownLoadModel

@end
